import type { EveningReflection } from "@/lib/companion/evening-reflection";

export default function EveningReflectionSection({
  reflection,
  childName,
}: {
  reflection: EveningReflection;
  childName: string;
}) {
  return (
    <section
      className="animate-fade-in rounded-[32px] border border-white/60 bg-white/80 p-8 shadow-[0_20px_56px_rgba(15,23,42,0.06)] backdrop-blur-sm lg:p-10"
      aria-labelledby="evening-reflection-heading"
    >
      <h1
        id="evening-reflection-heading"
        className="text-3xl font-bold tracking-tight text-[#0F172A] lg:text-4xl"
      >
        Good evening
      </h1>
      <p className="mt-2 text-lg text-[#64748B]">
        A quiet moment for {childName} and you — no statistics, just reflection.
      </p>

      <div className="mt-10 space-y-8">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
            One thing I learned today
          </p>
          <p className="mt-2 text-base leading-relaxed text-[#0F172A]">{reflection.learned}</p>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
            One encouraging observation
          </p>
          <p className="mt-2 text-base leading-relaxed text-[#475569]">{reflection.encouraging}</p>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
            One thing to keep in mind tomorrow
          </p>
          <p className="mt-2 text-base leading-relaxed text-[#475569]">{reflection.tomorrowMind}</p>
        </div>
      </div>
    </section>
  );
}
