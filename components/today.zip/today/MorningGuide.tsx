import ChildSwitcher from "@/components/app/ChildSwitcher";
import type { Child } from "@/lib/types/database";
import type { MorningGuide } from "@/lib/companion/morning-guide";

type MorningGuideProps = {
  guide: MorningGuide;
  familyChildren: Child[];
  activeChildId: string;
};

export default function MorningGuideSection({
  guide,
  familyChildren,
  activeChildId,
}: MorningGuideProps) {
  return (
    <section
      className="animate-fade-in rounded-[32px] border border-white/60 bg-white/80 p-8 shadow-[0_20px_56px_rgba(15,23,42,0.06)] backdrop-blur-sm lg:p-10"
      aria-labelledby="morning-guide-heading"
    >
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-xl space-y-6">
          <div>
            <h1
              id="morning-guide-heading"
              className="text-3xl font-bold tracking-tight text-[#0F172A] lg:text-4xl"
            >
              {guide.greeting}
            </h1>
            <p className="mt-3 text-lg leading-relaxed text-[#64748B]">{guide.subline}</p>
          </div>

          {guide.noticing && (
            <div className="space-y-1">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
                Here&apos;s what I&apos;m noticing
              </p>
              <p className="text-base leading-relaxed text-[#0F172A]">{guide.noticing}</p>
            </div>
          )}

          <div className="space-y-1">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
              Today&apos;s gentle recommendation
            </p>
            <p className="text-base leading-relaxed text-[#475569]">{guide.gentleRecommendation}</p>
          </div>

          {guide.nextStepHint && (
            <p className="text-sm text-[#64748B]">{guide.nextStepHint}</p>
          )}
        </div>
        {familyChildren.length > 1 && (
          <ChildSwitcher familyChildren={familyChildren} activeChildId={activeChildId} />
        )}
      </div>
    </section>
  );
}
