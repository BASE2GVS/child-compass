import Link from "next/link";
import DashboardBackground from "@/components/dashboard/DashboardBackground";
import ParentCheckIn from "@/components/today/ParentCheckIn";
import MorningGuideSection from "@/components/today/MorningGuide";
import EveningReflectionSection from "@/components/today/EveningReflection";
import DayJourney from "@/components/today/DayJourney";
import ContextualNextStepCard from "@/components/today/ContextualNextStep";
import GentlePromptSection from "@/components/today/GentlePromptSection";
import ChildSwitcher from "@/components/app/ChildSwitcher";
import { buildMorningGuide } from "@/lib/companion/morning-guide";
import { buildEveningReflection } from "@/lib/companion/evening-reflection";
import { buildDayJourney } from "@/lib/companion/day-journey";
import { buildContextualNextStep } from "@/lib/companion/contextual-next-step";
import { getDayPhase } from "@/lib/companion/daily-rhythm";
import type {
  Child,
  CoachMessage,
  DailyCheckin,
  PatternFinding,
} from "@/lib/types/database";

type TodayContentProps = {
  parentName: string;
  childName: string;
  childId: string;
  familyChildren: Child[];
  headlineInsight: string | null;
  recommendation: string | null;
  weeklyTrend: { trend: string; message: string } | null;
  checkin: DailyCheckin | null;
  yesterdayCheckin: DailyCheckin | null;
  patterns: PatternFinding[];
  weekCheckins: DailyCheckin[];
  coachMessages: CoachMessage[];
  firstCheckinOffer?: boolean;
};

function coachTalkedToday(messages: CoachMessage[]): boolean {
  const today = new Date().toISOString().split("T")[0];
  return messages.some((m) => m.role === "parent" && m.created_at.startsWith(today));
}

export default function TodayContent({
  parentName,
  childName,
  childId,
  familyChildren,
  headlineInsight,
  recommendation,
  weeklyTrend,
  checkin,
  yesterdayCheckin,
  patterns,
  weekCheckins,
  coachMessages,
  firstCheckinOffer = false,
}: TodayContentProps) {
  const today = new Date().toISOString().split("T")[0];
  const hasCheckinToday = checkin?.checkin_date === today;
  const phase = getDayPhase();
  const talkedToday = coachTalkedToday(coachMessages);
  const trend = (weeklyTrend?.trend as "improving" | "stable" | "declining" | undefined) ?? null;

  const morningGuide = buildMorningGuide({
    parentName,
    childName,
    checkin,
    yesterdayCheckin,
    weekCheckins,
    coachMessages,
    patterns,
    recommendation,
    headlineInsight,
    weeklyTrend: trend,
  });

  const eveningReflection = buildEveningReflection({
    childName,
    checkin,
    yesterdayCheckin,
    coachMessages,
    patterns,
    weeklyTrend: trend,
  });

  const journey = buildDayJourney({
    phase,
    hasCheckinToday,
    coachMessages,
    hasPatterns: patterns.length > 0,
  });

  const nextStep = buildContextualNextStep({
    phase,
    childId,
    childName,
    checkin,
    coachMessages,
    patterns,
    firstCheckinOffer,
  });

  return (
    <DashboardBackground>
      <div className="mx-auto max-w-2xl space-y-10 pb-8 lg:space-y-12">
        {phase === "morning" && (
          <>
            <MorningGuideSection
              guide={morningGuide}
              familyChildren={familyChildren}
              activeChildId={childId}
            />
            <ParentCheckIn parentName={parentName} childName={childName} />
          </>
        )}

        {phase === "day" && (
          <section className="animate-fade-in space-y-3 px-1">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-[#0F172A]">Today</h1>
                <p className="mt-1 text-[#64748B]">
                  {hasCheckinToday
                    ? `Here's where things stand with ${childName}.`
                    : `Whenever you're ready — one step at a time.`}
                </p>
              </div>
              {familyChildren.length > 1 && (
                <ChildSwitcher familyChildren={familyChildren} activeChildId={childId} />
              )}
            </div>
          </section>
        )}

        {phase === "evening" && (
          <>
            <EveningReflectionSection reflection={eveningReflection} childName={childName} />
            {familyChildren.length > 1 && (
              <div className="flex justify-end px-1">
                <ChildSwitcher familyChildren={familyChildren} activeChildId={childId} />
              </div>
            )}
          </>
        )}

        <DayJourney steps={journey} />

        <GentlePromptSection
          phase={phase}
          childId={childId}
          childName={childName}
          hasCheckinToday={hasCheckinToday}
          talkedToday={talkedToday}
        />

        <ContextualNextStepCard step={nextStep} />

        {phase !== "morning" && (
          <p className="text-center text-sm text-[#94A3B8]">
            <Link href={`/coach?child=${childId}`} className="hover:text-[#14B8A6]">
              Talk to Child Compass
            </Link>
            {" · "}
            <Link href={`/check-in?child=${childId}`} className="hover:text-[#14B8A6]">
              Check-in
            </Link>
          </p>
        )}
      </div>
    </DashboardBackground>
  );
}
