"use client";

import Link from "next/link";
import type { ContextualNextStep } from "@/lib/companion/contextual-next-step";

export default function ContextualNextStepCard({ step }: { step: ContextualNextStep }) {
  const { primary, alternates } = step;

  return (
    <section
      className="rounded-[28px] border border-[#14B8A6]/15 bg-gradient-to-br from-[#14B8A6]/[0.06] to-white p-8 shadow-[0_8px_32px_rgba(20,184,166,0.06)]"
      aria-labelledby="next-step-heading"
    >
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#14B8A6]">
        Today&apos;s next step
      </p>
      <h2 id="next-step-heading" className="mt-2 text-xl font-bold text-[#0F172A]">
        {primary.label}
      </h2>
      <p className="mt-2 max-w-lg text-sm leading-relaxed text-[#64748B]">{primary.description}</p>

      {primary.href !== "#skip" && (
        <Link
          href={primary.href}
          className="mt-6 inline-flex rounded-2xl bg-[#14B8A6] px-7 py-3.5 text-sm font-semibold text-white shadow-[0_8px_24px_rgba(20,184,166,0.3)] transition-colors hover:bg-[#0D9488]"
        >
          {primary.label}
        </Link>
      )}

      {alternates.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-x-4 gap-y-2 border-t border-[#F1EDE6] pt-5">
          {alternates.map((alt) =>
            alt.href === "#skip" ? (
              <span key={alt.id} className="text-sm text-[#94A3B8]">
                {alt.label}
              </span>
            ) : (
              <Link
                key={alt.id}
                href={alt.href}
                className="text-sm font-medium text-[#64748B] underline-offset-2 hover:text-[#14B8A6] hover:underline"
              >
                {alt.label}
              </Link>
            ),
          )}
        </div>
      )}
    </section>
  );
}
