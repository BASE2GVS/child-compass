"use client";

import { useState } from "react";
import {
  PARENT_MOOD_OPTIONS,
  parentMoodAcknowledgement,
  parentMoodStorageKey,
  type ParentMood,
} from "@/lib/companion/parent-checkin";

function readStoredMood(): ParentMood | null {
  if (typeof window === "undefined") return null;
  try {
    const stored = localStorage.getItem(parentMoodStorageKey());
    return (stored as ParentMood) || null;
  } catch {
    return null;
  }
}

type ParentCheckInProps = {
  parentName: string;
  childName: string;
  onMoodSelected?: (mood: ParentMood) => void;
};

export default function ParentCheckIn({ parentName, childName, onMoodSelected }: ParentCheckInProps) {
  const [mood, setMood] = useState<ParentMood | null>(readStoredMood);
  const [dismissed, setDismissed] = useState(false);

  function select(selected: ParentMood) {
    setMood(selected);
    try {
      localStorage.setItem(parentMoodStorageKey(), selected);
    } catch {
      // ignore
    }
    onMoodSelected?.(selected);
    if (selected === "skipped") setDismissed(true);
  }

  if (dismissed || mood === "skipped") return null;
  if (mood) {
    const ack = parentMoodAcknowledgement(mood, parentName, childName);
    return (
      <div className="rounded-[28px] border border-[#F1EDE6] bg-white/90 px-6 py-5 shadow-sm">
        <p className="text-sm leading-relaxed text-[#64748B]">{ack}</p>
        <button
          type="button"
          onClick={() => select("skipped")}
          className="mt-3 text-xs font-semibold text-[#94A3B8] hover:text-[#64748B]"
        >
          Change
        </button>
      </div>
    );
  }

  return (
    <section
      className="rounded-[28px] border border-[#F1EDE6] bg-white/80 p-6"
      aria-labelledby="parent-checkin-heading"
    >
      <h2 id="parent-checkin-heading" className="text-lg font-semibold text-[#0F172A]">
        How are you feeling?
      </h2>
      <p className="mt-1 text-sm text-[#64748B]">Optional — {childName} benefits when you&apos;re supported too.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {PARENT_MOOD_OPTIONS.map((opt) => (
          <button
            key={opt.id}
            type="button"
            onClick={() => select(opt.id)}
            className="rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-[#475569] shadow-sm ring-1 ring-[#E8E4DC] transition-all hover:bg-[#14B8A6]/5 hover:text-[#0D9488] hover:ring-[#14B8A6]/30"
          >
            {opt.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => select("skipped")}
          className="rounded-2xl px-4 py-2.5 text-sm font-medium text-[#94A3B8] hover:text-[#64748B]"
        >
          Skip
        </button>
      </div>
    </section>
  );
}
