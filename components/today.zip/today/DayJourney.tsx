import type { JourneyStep } from "@/lib/companion/day-journey";

export default function DayJourney({ steps }: { steps: JourneyStep[] }) {
  return (
    <section
      className="rounded-[28px] border border-[#F1EDE6]/80 bg-white/60 px-6 py-8"
      aria-label="Today's journey"
    >
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#94A3B8]">
        Today&apos;s journey
      </p>
      <ol className="mt-6 space-y-0">
        {steps.map((step, index) => (
          <li key={step.id} className="flex gap-4">
            <div className="flex flex-col items-center pt-1.5">
              <span
                className={`h-2 w-2 shrink-0 rounded-full ${
                  step.status === "done"
                    ? "bg-[#14B8A6]"
                    : step.status === "current"
                      ? "bg-[#14B8A6] ring-4 ring-[#14B8A6]/20"
                      : "bg-[#E2E8F0]"
                }`}
                aria-hidden
              />
              {index < steps.length - 1 && (
                <span
                  className={`my-1 w-px flex-1 min-h-[2rem] ${
                    step.status === "done" ? "bg-[#14B8A6]/30" : "bg-[#E8E4DC]"
                  }`}
                  aria-hidden
                />
              )}
            </div>
            <p
              className={`pb-7 text-sm leading-relaxed ${
                step.status === "current"
                  ? "font-medium text-[#0F172A]"
                  : step.status === "done"
                    ? "text-[#64748B]"
                    : "text-[#94A3B8]"
              }`}
            >
              {step.label}
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}
