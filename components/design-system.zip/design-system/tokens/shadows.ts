/**
 * Shadows — paper resting on a table, not floating SaaS widgets.
 */
export const shadows = {
  /** Barely lifted paper */
  paper:
    "shadow-[0_1px_2px_rgba(45,42,38,0.04),0_4px_12px_rgba(45,42,38,0.04)]",
  /** Standard card — soft depth */
  card:
    "shadow-[0_2px_8px_rgba(45,42,38,0.05),0_8px_24px_rgba(45,42,38,0.04)]",
  /** Hero / featured surfaces */
  hero:
    "shadow-[0_4px_16px_rgba(45,42,38,0.06),0_12px_40px_rgba(45,42,38,0.05)]",
  /** Hover lift — gentle */
  lift:
    "shadow-[0_8px_28px_rgba(45,42,38,0.08),0_2px_8px_rgba(45,42,38,0.04)]",
  /** Inset — pressed paper */
  inset: "shadow-[inset_0_1px_2px_rgba(45,42,38,0.06)]",
  /** Teal glow for primary actions */
  tealGlow: "shadow-[0_8px_28px_var(--cc-teal-glow)]",
  /** None */
  none: "shadow-none",
} as const;
