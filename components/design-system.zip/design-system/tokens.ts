/**
 * Child Compass 3.0 — unified `ds` surface + legacy compatibility.
 * New pages should import from `./tokens/*` directly; `ds` maps emotional tokens.
 */
import { layoutSpace, touchTarget } from "./tokens/spacing";
import { typeScale } from "./tokens/typography";
import { radius } from "./tokens/radius";
import { shadows } from "./tokens/shadows";
import { motion } from "./tokens/motion";

/** @deprecated use layoutSpace from ./tokens */
export const space = layoutSpace;

export const ds = {
  /* Surfaces */
  card: `${radius.cardHero} bg-[var(--cc-paper-elevated)] ${shadows.card}`,
  glass: `${radius.cardHero} border border-[var(--cc-border-soft)] bg-[var(--cc-paper)]/90 ${shadows.paper} backdrop-blur-sm`,
  paper: `${radius.card} bg-[var(--cc-paper-elevated)] ${shadows.paper}`,
  hero: `${radius.hero} bg-gradient-to-br from-[var(--cc-paper-elevated)] via-[var(--cc-paper)] to-[var(--cc-teal-wash)]/40 ${shadows.hero}`,

  /* Forms */
  input: `w-full min-h-12 ${radius.input} border-0 bg-[var(--cc-cream-100)] px-4 py-3.5 text-base text-[var(--cc-ink)] outline-none ring-1 ring-[var(--cc-border)] transition-shadow placeholder:text-[var(--cc-ink-faint)] focus:ring-2 focus:ring-[var(--cc-teal)]/25 disabled:opacity-60`,
  label: "mb-1.5 block text-sm font-semibold text-[var(--cc-ink)]",
  hint: "mt-1.5 text-sm leading-relaxed text-[var(--cc-ink-faint)]",
  fieldError: "mt-1.5 text-sm font-medium text-[var(--cc-danger)]",

  /* Typography shortcuts */
  eyebrow: typeScale.eyebrow,
  heading: typeScale.title,
  subtext: `mt-3 max-w-2xl ${typeScale.body}`,

  /* Buttons */
  btnPrimary: `inline-flex ${touchTarget} items-center justify-center ${radius.button} bg-[var(--cc-teal)] px-6 py-3.5 text-sm font-semibold text-white ${shadows.tealGlow} transition-all duration-200 hover:bg-[var(--cc-teal-deep)] hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cc-teal)]/40 ${motion.press} disabled:opacity-50 motion-reduce:transition-none motion-reduce:hover:translate-y-0`,
  btnSecondary: `inline-flex ${touchTarget} items-center justify-center ${radius.button} border border-[var(--cc-border)] bg-[var(--cc-paper-elevated)] px-6 py-3.5 text-sm font-semibold text-[var(--cc-ink)] ${shadows.paper} transition-all duration-200 hover:bg-[var(--cc-cream-100)] hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cc-teal)]/25 ${motion.press} motion-reduce:transition-none motion-reduce:hover:translate-y-0`,
  btnGhost: `inline-flex ${touchTarget} items-center justify-center ${radius.button} px-5 py-3 text-sm font-semibold text-[var(--cc-ink-muted)] transition-colors hover:bg-[var(--cc-cream-100)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cc-teal)]/25`,
  btnPill: `inline-flex ${touchTarget} items-center justify-center ${radius.pill} bg-[var(--cc-teal)] px-7 py-3.5 text-sm font-semibold text-white ${shadows.tealGlow} transition-all duration-200 hover:bg-[var(--cc-teal-deep)] ${motion.press}`,
  btnFab: `inline-flex h-14 w-14 min-h-14 min-w-14 items-center justify-center ${radius.pill} bg-[var(--cc-teal)] text-white ${shadows.tealGlow} transition-all duration-200 hover:bg-[var(--cc-teal-deep)] hover:scale-105 ${motion.press} motion-reduce:hover:scale-100`,

  /* Motion */
  hoverLift: motion.liftCard,
  fadeIn: motion.fadeIn,
  stagger: "animate-cc-stagger-in",
} as const;
